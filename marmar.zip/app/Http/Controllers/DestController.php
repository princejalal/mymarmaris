<?php

namespace App\Http\Controllers;

use App\Blog;
use App\Destination_info;
use App\Destinations;
use App\District;
use App\Tour;
use App\Tour_info;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class DestController extends MyController {

    public function index($destName){

            $destinationInfo = Destination_info::where('lang_id',get_lang_id(App::getLocale()))
                ->where('url',$destName)
                ->first();

            if($destinationInfo):
                $scrollText = $destinationInfo->scrolling_text;

                $dest_id = $destinationInfo->destination_id;

                $destInfo = Destinations::where('destination_id',$dest_id)->first();


                $tagId = 'tag_id';
                if(App::getLocale() != 'en'):
                    $tagId = 'parent';
                endif;

                $tours = Tour::select('tour.*', 'tour_photo.photo_path', 'tour_price.price', 'tour_price.currency_id', 'tour_info.url',
                    'tour_info.tour_name as t_name', 'tour_info.tour_header', 'tour_info.tour_explain','tourGif.gif',DB::raw('IFNULL(tourTag.tName,null) as tag_name'))
                    ->where('publish', 1)->where('parent_id', 0)->where('tour_info.lang_id', get_lang_id(App::getLocale()))
                    ->where('tour_price.age_range', 'adult')
                    ->where('destination_id',$dest_id)
                    ->orWhere('tour_photo.cover',1)
                    ->where('tour_price.currency_id', Session::get('currency_id'))
                    ->leftJoin('tour_info', 'tour_info.tour_id', '=', 'tour.tour_id')
                    ->leftJoin(DB::raw('(SELECT tag_id,tag_name as tName,parent FROM tour_tag WHERE lang_id = '.get_lang_id(App::getLocale()).') tourTag'), DB::raw('tourTag.'.$tagId), '=', 'tour.tour_tag')
                    ->leftJoin('tour_photo', 'tour_photo.tour_id', '=', 'tour.tour_id')
                    ->leftJoin(DB::raw('(SELECT photo_id,tour_id,photo_path as gif FROM tour_photo WHERE gif = 1) tourGif'), DB::raw('tourGif.tour_id'), '=', 'tour.tour_id')
                    ->leftJoin('tour_price', 'tour_price.tour_id', '=', 'tour.tour_id')
                    ->groupBy('tour.tour_id')
                    ->get();



                $title = $destinationInfo->title;

                return view('home.dest',compact('destinationInfo','tours','destInfo','scrollText','title'));
            endif;

    }


}
