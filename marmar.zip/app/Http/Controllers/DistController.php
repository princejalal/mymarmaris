<?php

namespace App\Http\Controllers;

use App\Destination_info;
use App\District;
use App\District_info;
use App\Tour;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;

class DistController extends MyController {


    public function index($destname, $distName) {

        $url = str_replace('-', ' ', $distName);

        $destUrl = str_replace('-',' ',$destname);

        $dist = District_info::where('lang_id',get_lang_id(App::getLocale()))->where('url',$distName)->first();

        if ($dist):

            $distric = District::where('district_id', $dist->district_id)->first();

            $tagId = 'tag_id';
            if(App::getLocale() != 'en'):
                $tagId = 'parent';
            endif;

            $data = [
                'distInfo' => $dist,
                'destInfo' => Destination_info::where('url', $destname)->where('lang_id', get_lang_id(App::getLocale()))->orWhere('url',$destUrl)->first(),
                'tours' => Tour::select('tour.*','tour.parent_id as tour_id','tour_photo.photo_path','tour_price.price','tour_price.currency_id',
                    'tour_info.url','tour_info.tour_name as t_name','tour_info.tour_header','tour_info.tour_explain','tourGif.gif',DB::raw('IFNULL(tourTag.tName,null) as tag_name'))
                    ->where('tour.district_id',$distric->district_id)
                    ->where('tour.publish',1)->where('tour_info.lang_id',get_lang_id(App::getLocale()))
                    ->where('tour_price.age_range','adult')
                    ->leftJoin('tour_info','tour_info.tour_id','=','tour.tour_id')
                    ->leftJoin('tour_photo','tour_photo.tour_id','=','tour.parent_id')
                    ->leftJoin(DB::raw('(SELECT tag_id,tag_name as tName,parent FROM tour_tag WHERE lang_id = '.get_lang_id(App::getLocale()).') tourTag'), DB::raw('tourTag.'.$tagId), '=', 'tour.tour_tag')
                    ->leftJoin(DB::raw('(SELECT photo_id,tour_id,photo_path as gif FROM tour_photo WHERE gif = 1) tourGif'), DB::raw('tourGif.tour_id'), '=', 'tour.parent_id')
                    ->leftJoin('tour_price','tour_price.tour_id','=','tour.parent_id')
                    ->groupBy('tour.tour_id')
                    ->get(),
                'scrollText' => $dist->scrolling_text,
                'DestinationInfo' => Destination_info::where('lang_id',get_lang_id(App::getLocale()))
                    ->where('url',$destname)
                    ->first(),
                'dist' => $distric,
                'title'=> $dist->title,
                'metaDesc'=>$dist->meta_desc,
                'metaTags'=>$dist->meta_tags
            ];


            return view('home.dist', $data);

        endif;

        redirect('/' . App::getLocale());

    }
}
