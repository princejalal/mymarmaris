<?php

namespace App\Http\Controllers;

use App\Currency;
use App\Destination_info;
use App\Destinations;
use App\District_info;
use App\Photo;
use App\Tour;
use App\Tour_info;
use App\Tour_price;
use App\Tour_program;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class TourController extends MyController {

    public function base($tourName) {

        $tour_url = str_replace('-', ' ', $tourName);

        $langId = $this->langId[App::getLocale()];

        $tour_info = Tour_info::where('url', $tour_url)->where('lang_id', $langId)->first();

        $tour = Tour::where('tour_id', $tour_info->tour_id)->where('publish', 1)->first();

        $tourId = $tour->tour_id;

        if ($tour->parent_id != 0):

            $tourId = $tour->parent_id;

        endif;

        $data = ['tourPhoto' => Photo::where('tour_id', $tourId)->where('gif', 0)->get(), 'tourPriceAdult' => Tour_price::where('age_range', 'adult')->where('tour_id', $tourId)->where('currency_id', Session::get('currency_id'))->first(), 'prices' => Tour_price::where('tour_id', $tourId)->where('tour_price.currency_id', Session::get('currency_id'))->get(), 'tourProgram' => Tour_program::where('tour_id', $tourId)->where('lang_id', $langId)->orWhere('lang_id', 1)->first(), 'tourInfo' => $tour_info, 'destination' => Destination_info::where('destination_id', $tour->destination_id)->where('lang_id', $langId)->orWhere('lang_id', 1)->first(), 'scrollText' => $tour_info->scrolling_text, 'tourCurrency' => Currency::where('currency_id', Session::get('currency_id'))->first(), 'TourGif' => Photo::where('tour_id', $tourId)->where('gif', 1)->first(), 'tourId' => $tourId];

        return view('tour.index', $data);

    }


    public function show($destName, $distName, $tourName) {

        // $tour_url = str_replace('-', ' ', $tourName);
        //
        // $langId = get_lang_id(App::getLocale());
        //
        // $tour_info = Tour_info::where('url', $tour_url)->where('lang_id', $langId)->first();
        //
        //
        // $tour = Tour::where('tour_id', $tour_info->tour_id)->where('publish', 1)->first();
        //
        // $tour_program = Tour_program::where('tour_id',$tour_info->tour_id)->where('lang_id',$langId)->first();
        //
        // if(!$tour_program):
        //
        //     $tour_program = Tour_program::where('tour_id', $tour->parent_id)->where('lang_id', $langId)->orWhere('lang_id', 1)->first();
        //
        // endif;
        //
        //
        // $tourId = $tour->tour_id;
        //
        // if ($tour->parent_id != 0):
        //
        //     $tourId = $tour->parent_id;
        //
        // endif;
        //
        // $data = [
        //     'tourPhoto' => Photo::where('tour_id', $tourId)->where('gif', 0)->get(),
        //     'tourPriceAdult' => Tour_price::where('age_range', 'adult')->where('tour_id', $tourId)->where('currency_id', Session::get('currency_id'))->first(),
        //     'prices' => Tour_price::where('tour_id', $tourId)->where('tour_price.currency_id', Session::get('currency_id'))->get(),
        //     'tourProgram' => $tour_program,
        //     'tourInfo' => $tour_info,
        //     'destination' => Destination_info::where('destination_id', $tour->destination_id)->where('lang_id', $langId)->orWhere('lang_id', 1)->first(),
        //     'scrollText' => $tour_info->scrolling_text, 'tourCurrency' => Currency::where('currency_id', Session::get('currency_id'))->first(),
        //     'TourGif' => Photo::where('tour_id', $tourId)->where('gif', 1)->first(),
        //     'tourId' => $tourId,
        //     'district'=>District_info::where('district_id',$tour->district_id)->where('lang_id',get_lang_id(App::getLocale()))->first(),
        //     'title'=>$tour_info->title,
        //     'metaDesc'=>$tour_info->meta_desc,
        //     'metaTags'=>$tour_info->meta_tags
        // ];
        //
        // return view('tour.index', $data);


    }

}
