<?php

namespace App\Http\Controllers;

use App\Blog;
use App\Destination_info;
use App\Destinations;
use App\Page_info;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class BlogController extends MyController {


    public function __construct(Request $request) {
        parent::__construct($request);

        $lastedPost = Blog::where('publish', 1)->orderBy('created_at', 'DESC')->limit(10)->paginate(10);


        View::share('lastedPost', $lastedPost);

    }


    public function index($destName = null) {

        $posts = Blog::where('publish', 1)->where('lang_id', get_lang_id(App::getLocale()))->paginate(10);

        if ($destName != null):

            $url = str_replace('-', ' ', $destName);

            $destintion = Destination_info::where('url', $url)->first();

            $posts = Blog::where('publish', 1)->where('destination_id', $destintion->destination_id)->where('lang_id',
                get_lang_id(App::getLocale()))->paginate(10);

        endif;


        $blogInfo = Page_info::where('page_id', 2)->where('lang_id', get_lang_id(App::getLocale()))->first();

        if (!$blogInfo):
            $blogInfo = new \stdClass();
        endif;

        $title = check_property($blogInfo, 'title');
        $metaDesc = check_property($blogInfo, 'meta_desc');
        $metaTags = check_property($blogInfo, 'meta_tags');

        return view('blog.base', compact('posts', 'blogInfo', 'title', 'metaDesc', 'metaTags'));

    }


    public function show($title) {

        $name = str_replace('-', ' ', $title);

        $blogContent = Blog::where('title', $name)->first();

        Blog::where('blog_id', $blogContent->blog_id)->update(['view' => DB::raw('view + 1')]);

        $title = $blogContent->title;
        $metaDesc = $blogContent->meta_desc;
        $metaTags = $blogContent->meta_tags;

        $blogInfo = Page_info::where('page_id', 2)->where('lang_id', get_lang_id(App::getLocale()))->first();

        if (!$blogInfo):
            $blogInfo = new \stdClass();
        endif;

        return view('blog.show', compact('blogContent', 'title', 'metaTags', 'metaDesc','blogInfo'));
    }

}
