<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Default_content extends Model {

    protected $table = 'default_contents';



}
